clc
clear
cd ''
N = readtable('File names 2016.xlsx');
N2 = table2cell(N);
N3 = regexprep (N2 , '[^0-9,-]','');
N3=strcat(N3,'-2015.csv'); 
S1=strcat('W-CrawfordvilleElementarySchool',N3);
Weather(1:2,1:35040)=0;
cd ''
for i=1:73
    D=readtable(char(S1(i)));
    D2 = table2cell(D);
    D3= regexprep (D2 , '[^0-9,.,-]','');
    D4 = D3(3:482,5)';
    D5= D3(3:482,6)';
    D6(1,:)=D4';
    D6(2,:)=D5';
    P=str2double(D6);
    Weather(1:2,(i*480)-479:i*480)=P(1:2,:);
end


cd ''
csvwrite('W-CrawfordvilleElementarySchool-all-converted-PCA.csv',Weather');
csvwrite('W-CrawfordvilleElementarySchool-all-converted.csv',Weather(1,1:35040)');