cd 'C:\Users\h.panamtash\OneDrive\My papers\PSC 2018\Benchmarks'
M = readtable('Kingsway Elementary-01-01-2015.csv');
M2 = table2cell(M);
M3 = regexprep (M2 , '[^0-9,.,-]','');
MM = M3(4:483,2);
m=str2double(MM);
csvwrite('Kingsway Elementary-01-01-2015-converted.csv',m)
N = readtable('File names 2015.xlsx');
N2 = table2cell(N);
for i=1:30
    N3(i)=strcat(N2(i),'-2015.csv'); 
end