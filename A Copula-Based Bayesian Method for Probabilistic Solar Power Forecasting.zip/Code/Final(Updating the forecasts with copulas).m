clc
clear
%--------------------------------------------------------------------------
% Reading the benchmark forecast
%--------------------------------------------------------------------------
cd ''
BF = csvread('BF.csv',0,0);
%--------------------------------------------------------------------------
% Reading the forecast using only power
%--------------------------------------------------------------------------
cd ''
p1 = csvread('"Model".results.csv',1,1);
%--------------------------------------------------------------------------
% Reading the forecast using power and temperature
%--------------------------------------------------------------------------
p2 = csvread('W"Model".results.csv',1,1);
%--------------------------------------------------------------------------
% Reading the temperature data
%--------------------------------------------------------------------------
T = csvread('WT.csv',1,1);
%--------------------------------------------------------------------------
% The actual power output
%--------------------------------------------------------------------------
pa = csvread('Actual.csv',1,1);
%--------------------------------------------------------------------------
% Reading the copula
%--------------------------------------------------------------------------
cd ''

minT = csvread('minT.csv');
maxT = csvread('maxT.csv');

copulaT = csvread('copula.csv');
%--------------------------------------------------------------------------
% Normalizing the data
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
% Finding the max
%--------------------------------------------------------------------------
maximum.p1 = max(p1);
maximum.p2 = max(p2);
maximum.pa = max(pa);
%--------------------------------------------------------------------------
maximum.p = max(maximum.p1,maximum.p2);
maximum.p = max(maximum.p,maximum.pa)+2;
%--------------------------------------------------------------------------
% Finding the min
%--------------------------------------------------------------------------
minimum.p1 = min(p1);
minimum.p2 = min(p2);
minimum.pa = min(pa);
%--------------------------------------------------------------------------
minimum.p = min(minimum.p1,minimum.p2);
minimum.p = min(minimum.p,minimum.pa);
minimum.p = 0;
%--------------------------------------------------------------------------
% Normalizing
%--------------------------------------------------------------------------
p1 = (p1-minimum.p)/(maximum.p-minimum.p);
p2 = (p2-minimum.p)/(maximum.p-minimum.p);
pa = (pa-minimum.p)/(maximum.p-minimum.p);
%--------------------------------------------------------------------------
% Ploting
%--------------------------------------------------------------------------
% plot(p1,'r');
% hold on
% plot(p2,'b');
% plot(pa,'g');
%--------------------------------------------------------------------------
% Probability variables
%--------------------------------------------------------------------------
Meshsize = 100;
%--------------------------------------------------------------------------
% Reading Sigmas
%--------------------------------------------------------------------------
Sigma = csvread('Sigmas.csv')*5;
%--------------------------------------------------------------------------
% Probability calculation for p1
%--------------------------------------------------------------------------
r(1:size(p1)) = 0;
probability.p1(1:size(p1),1:Meshsize) = 0;
for i=1:size(p1)
    r(i) = round(p1(i)*Meshsize);
    for j=1:Meshsize
        probability.p1(i,j) = exp(-(((r(i)-j)/Meshsize*100)^2/sigma^2));
    end
end

summ.p1 = sum(probability.p1,2);

probability.p1 = probability.p1./summ.p1;
%--------------------------------------------------------------------------
% Probability calculation for p2
%--------------------------------------------------------------------------
r(1:size(p2)) = 0;
probability.p2(1:size(p2),1:Meshsize) = 0;
for i=1:size(p2)
    r(i) = round(p2(i)*Meshsize);
    for j=1:Meshsize
        probability.p2(i,j) = exp(-(((r(i)-j)/Meshsize*100)^2/sigma^2));
    end
end

summ.p1 = sum(probability.p2,2);

probability.p2 = probability.p2./summ.p1;
%--------------------------------------------------------------------------
% Normalizing temperature
%--------------------------------------------------------------------------
T = (T-minT)/(maxT-minT);
%--------------------------------------------------------------------------
% Updating the probability of p1 with temperature copula
%--------------------------------------------------------------------------
probability.p1updated(1:size(p1),1:Meshsize) = 0;
for i=1:size(p1)
    r(i) = round(T(i)*Meshsize);
    if (r(i)==0)
        r(i) = 1;
    end
    for j=1:Meshsize
        probability.p1updated(i,j) = probability.p1(i,j).*copulaT(j,r(i)).^1.6;
    end
    
end

summ.p1updated = sum(probability.p1updated,2);

probability.p1updated = probability.p1updated./summ.p1updated;

%probability.p1 = probability.p1updated;

surfl(probability.p2);

%--------------------------------------------------------------------------
% Calculating the 10% to 90% forecasts of p1
%--------------------------------------------------------------------------
NP = 99; % Number of quantiles
P1.p(1:NP,1:size(p1)) = 0;
P1.done = 0;
P1.sum = 0;
for i=1:size(p1)
    P1.sum = 0;
    P1.done = 0;
    for j=1:Meshsize
        P1.sum = P1.sum+probability.p1updated(i,j);
        for k=1:NP
            if(P1.sum>(1/(NP+1))*(P1.done+1) && P1.done<k)
                P1.p(k,i) = j;
                P1.done=P1.done +1;
            end
        end
    end
end
%--------------------------------------------------------------------------
% Calculating the 1% to 99% forecasts of p1 not updated
%--------------------------------------------------------------------------
NP = 99; % Number of quantiles
P1.pnot(1:NP,1:size(p1)) = 0;
P1.done = 0;
P1.sum = 0;
for i=1:size(p1)
    P1.sum = 0;
    P1.done = 0;
    for j=1:Meshsize
        P1.sum = P1.sum+probability.p1(i,j);
        for k=1:NP
            if(P1.sum>(1/(NP+1))*(P1.done+1) && P1.done<k)
                P1.pnot(k,i) = j;
                P1.done=P1.done +1;
            end
        end
    end
end
%--------------------------------------------------------------------------
% Calculating the 1% to 99% forecasts of p2
%--------------------------------------------------------------------------
P2.p(1:NP,1:size(p2)) = 0;
P2.done = 0;
P2.sum = 0;
for i=1:size(p2)
    P2.sum = 0;
    P2.done = 0;
    for j=1:Meshsize
        P2.sum = P2.sum+probability.p2(i,j);
        for k=1:NP
            if(P2.sum>(1/(NP+1))*(P2.done+1) && P2.done<k)
                P2.p(k,i) = j;
                P2.done=P2.done +1;
            end
        end
    end
end
P2.p(1:NP,1:29) = 0;
P2.p(1:NP,size(p2)-26:size(p2)) = 0;
for i=1:size(p1)
    if(pa(i)==0)
        P1.p(1:NP,i)=0;
        P1.pnot(1:NP,i)=0;
        P2.p(1:NP,i)=0;
    end
end
%--------------------------------------------------------------------------
% Plotting the 1% and 99% forecasts of p1
%--------------------------------------------------------------------------
plot(P1.p(1,:)/100,'b');
hold on
plot(P1.pnot(1,:)/100,'r');
%--------------------------------------------------------------------------
% Plotting the 1% and 99% forecasts of p2
%--------------------------------------------------------------------------
% plot(P2.p(1,:)/100,'-r');
% plot(P2.p(NP,:)/100,'-r');
plot(pa,'.k');

    
%--------------------------------------------------------------------------
% Pinball caculation P1
%--------------------------------------------------------------------------
Pinball.p1(1:NP,1:size(p1)) = 0;
for i=1:NP
    for j=1:size(p1)
        if(P1.p(i,j)/100>pa(j))
            Pinball.p1(i,j)=i/(NP+1)*(P1.p(i,j)/100-pa(j));
        else
            Pinball.p1(i,j)=-(NP+1-i)/(NP+1)*(P1.p(i,j)/100-pa(j));
        end
    end
end
%--------------------------------------------------------------------------
% Pinball caculation P1 not updated
%--------------------------------------------------------------------------
Pinball.p1not(1:NP,1:size(p1)) = 0;
for i=1:NP
    for j=1:size(p1)
        if(P1.pnot(i,j)/100>pa(j))
            Pinball.p1not(i,j)=i/(NP+1)*(P1.pnot(i,j)/100-pa(j));
        else
            Pinball.p1not(i,j)=-(NP+1-i)/(NP+1)*(P1.pnot(i,j)/100-pa(j));
        end
    end
end
%--------------------------------------------------------------------------
% Pinball caculation P2
%--------------------------------------------------------------------------
Pinball.p2(1:NP,1:size(p2)) = 0;
for i=1:NP
    for j=1:size(p2)
        if(P2.p(i,j)/100>pa(j))
            Pinball.p2(i,j)=i/(NP+1)*(P2.p(i,j)/100-pa(j));
        else
            Pinball.p2(i,j)=-(NP+1-i)/(NP+1)*(P2.p(i,j)/100-pa(j));
        end
    end
end

%--------------------------------------------------------------------------
% Total Pinball
%--------------------------------------------------------------------------
Pinball.P1 = sum(sum(Pinball.p1))/NP/7/96;
Pinball.P1not = sum(sum(Pinball.p1not))/NP/7/96;
Pinball.P2 = sum(sum(Pinball.p2))/NP/7/96;
    
    
    
[meanCRPSP1] = crps(P1.p/100,pa);
[meanCRPSP2] = crps(P2.p/100,pa);
[meanCRPSBF] = crps(BF,pa);
CRPS_score_P1 = 1-meanCRPSP1/meanCRPSBF;
CRPS_score_P2 = 1-meanCRPSP2/meanCRPSBF;

% Copyright 2014 Durga Lal Shrestha
