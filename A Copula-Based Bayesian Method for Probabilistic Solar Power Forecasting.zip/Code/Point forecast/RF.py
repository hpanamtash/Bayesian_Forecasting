#print(__doc__)

# Author: Hossein Panamtash <hpanam@ece.ucf.edu>

# ---------------------------------------------------------------------------------------------------------------------
import numpy as np
import sys
import csv
import math
import array
import matplotlib.pyplot as plt

from sklearn import ensemble
from sklearn import datasets
from sklearn.utils import shuffle
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor

# ---------------------------------------------------------------------------------------------------------------------
# Load data
Offset = Season offset
Trainsize = 31*96
Testsize = 7*96
Datasize = Trainsize+Testsize
n = np.zeros((1,Datasize))
print(n[0][1])
with open('Power data') as csv_file:
    csv_reader = csv.reader(csv_file, quoting=csv.QUOTE_NONNUMERIC)
    line_count = 0
    print(f'Processed {line_count} lines.')
    m=[]
    for row in csv_reader:
        m.append(float(row[0]))
n = m
# ---------------------------------------------------------------------------------------------------------------------

alldata = m

# ---------------------------------------------------------------------------------------------------------------------
#alldata = float(alldata)
#Max_data = float(max(alldata))
#Min_data = float(min(alldata))
#newalldata = [float(i) for i in alldata]
#newalldata = float(newalldata)
newalldata = np.array(alldata,dtype=float)
#print(type(newalldata))


# ---------------------------------------------------------------------------------------------------------------------

traindata = newalldata[0+Offset:Offset+Trainsize]
testdata = newalldata[Offset+Trainsize:Offset+Datasize]
#print(len(traindata))
Train_2 = traindata[0:Trainsize-2]
Train_1 = traindata[1:Trainsize-1]
Train_y = traindata[2:Trainsize]
Train_x = np.zeros((2,Trainsize-2))
Train_x[0][:] = Train_1
Train_x[1][:] = Train_2
Test_x = np.zeros((2,Testsize))
Test_x[0][0] = traindata[Trainsize-1]
Test_x[0][1:] = testdata[0:Testsize-1]
Test_x[1][0:1] = traindata[Trainsize-1:Trainsize]
Test_x[1][2:] = testdata[0:Testsize-2]
Test_y = testdata

Train_x = np.transpose(Train_x)
Test_x = np.transpose(Test_x)

# ---------------------------------------------------------------------------------------------------------------------

# Train_x = np.reshape(Train_x,(1,-1))
# Train_y = np.reshape(Train_y,(1,-1))
# Test_x = np.reshape(Test_x,(-1,1))
# Test_y = np.reshape(Test_y,(-1,1))
#print(len(Train_x))

# ---------------------------------------------------------------------------------------------------------------------

clf = RandomForestRegressor(n_estimators = 500, random_state = 20)
clf.fit(Train_x, Train_y)

forecast = clf.predict(Test_x)
mse = mean_squared_error(Test_y, clf.predict(Test_x))
rmse = math.sqrt(mse)
print("RMSE: %.4f" % rmse)

# ---------------------------------------------------------------------------------------------------------------------

plt.plot(Test_y)
plt.plot(clf.predict(Test_x))
plt.show()

with open('Actual.csv', 'a') as csvFile:
    writer = csv.writer(csvFile)
    writer.writerow(Test_y)
csvFile.close()

with open('RF.results.csv', 'a') as csvFile:
    writer = csv.writer(csvFile)
    writer.writerow(forecast)
csvFile.close()
