getwd()
setwd("")
getwd()

#------------------------------------------------------------------------------------------------
# Libraries
#------------------------------------------------------------------------------------------------

library('ggplot2')
library('forecast')
library('tseries')
library('quantreg')
library('neuralnet')
library('readxl')
library('forecast')
library('astsa')
library('gbm')

#------------------------------------------------------------------------------------------------
# Data input and definition
#------------------------------------------------------------------------------------------------

data<-read.csv(file="BayshoreElementary-all-converted.csv",head=FALSE,sep=",")
d <- t(data)
d2 <- t(d)
Datasize <- 96*38
Trainsize <- 96*7+2
Testsize <- 96*7

train.data = d2[17377:(Trainsize+17376)]
test.data = d2[(Datasize+16705):(Datasize+17376)]

#------------------------------------------------------------------------------------------------
# train data missing and negetive
#------------------------------------------------------------------------------------------------

sum(is.na(train.data))

for (i in 1:(Trainsize-1)) {
  if (is.na(train.data[i])){
    train.data[i] <- train.data[i-1];
  }
}

for (i in 1:Trainsize) {
  if (train.data[i] < 0){
    train.data[i] <- 0;
  }
}
sum(is.na(train.data))

#------------------------------------------------------------------------------------------------
# test data missing and negetive
#------------------------------------------------------------------------------------------------

sum(is.na(test.data))

for (i in 1:(Testsize-1)) {
  if (is.na(test.data[i])){
    test.data[i] <- test.data[i-1];
  }
}

for (i in 1:Testsize) {
  if (test.data[i] < 0){
    test.data[i] <- 0;
  }
}

sum(is.na(test.data))
#------------------------------------------------------------------------------------------------
# Scaling and prepairing the training data
#------------------------------------------------------------------------------------------------

max.train = max(train.data)
min.train = min(train.data)

data.scaled <- as.data.frame(scale(train.data, center = min.train, scale = max.train - min.train))
data.scaled.l1 = data.scaled[1:(Trainsize-1),1]
data.scaled.l2 = data.scaled[1:(Trainsize-2),1]

train_1 <- data.scaled.l1[2:(Trainsize-1)]
train_2 <- data.scaled.l2[1:(Trainsize-2)]
#------------------------------------------------------------------------------------------------
# GB training
#------------------------------------------------------------------------------------------------

train <- data.frame(train_1,train_2)
goal <- data.scaled[3:(Trainsize),1]

nn <- glm(goal~train_1+train_2,
          data = train)
#------------------------------------------------------------------------------------------------
# Scaling prepairing the test data
#------------------------------------------------------------------------------------------------

max.test = max(test.data)
min.test = min(test.data)

test.scaled <- as.data.frame(scale(test.data, center = min.test, scale = max.test - min.test))
test.scaled.l1 = test.scaled[1:(Trainsize-1),1]
test.scaled.l2 = test.scaled[1:(Trainsize-2),1]


test_1 = 0
test_1[1] = train.data[Trainsize]
test_1[2:Testsize] <- test.scaled.l1

test_2 = 0
test_2[1:2] = train.data[(Testsize-1):Testsize]
test_2[3:Testsize] <- test.scaled.l2



test <- data.frame(test_1,test_2)
#------------------------------------------------------------------------------------------------
# Forecasting
#------------------------------------------------------------------------------------------------
pr.nn <- predict(nn, newdata = test, n.trees=10000)


forecast <- 0
forecast <- pr.nn*(max.test-min.test)+min.test

#------------------------------------------------------------------------------------------------
# Ploting
#------------------------------------------------------------------------------------------------

plot(test.data, xlab="Time (5 min)", type="p", pch=19, col="black", ylab="Power output (MW)")
lines(forecast, pch=18, col="red",type="l")
legend(250, 35, legend=c("Forecasted", "Actual"),
       col=c("black", "red"), lty=c(3,1), cex=0.8)

#------------------------------------------------------------------------------------------------
# Error Calculation
#------------------------------------------------------------------------------------------------

error = sqrt(sum((forecast-test.data)^2)/Testsize)

setwd("")
write.csv(forecast, file="MLR.results.csv")
write.csv(test.data, file="Actual.csv")